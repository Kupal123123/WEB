<!-- Buy Now Button - place this inside your product card loop -->
<button class="buy-now" name="buy" id="buy-now" onclick="buyNow(<?php echo $product['product_id']; ?>, '<?php echo $product['product_name']; ?>', '<?php echo $product['product_price']; ?>')">
    Buy now
</button>
